# Security System - Quick Setup Script
# Run this script to setup the backend quickly

Write-Host "🔒 Security System - Setup Script" -ForegroundColor Cyan
Write-Host "=================================" -ForegroundColor Cyan
Write-Host ""

# Check if PostgreSQL is running
Write-Host "📊 Step 1: Checking PostgreSQL..." -ForegroundColor Yellow
try {
    $pgStatus = Get-Service -Name postgresql* -ErrorAction SilentlyContinue
    if ($pgStatus) {
        Write-Host "✓ PostgreSQL service found" -ForegroundColor Green
    } else {
        Write-Host "⚠ PostgreSQL service not found. Please install PostgreSQL first." -ForegroundColor Red
        exit
    }
} catch {
    Write-Host "⚠ Could not check PostgreSQL status" -ForegroundColor Yellow
}

Write-Host ""
Write-Host "📦 Step 2: Installing Python dependencies..." -ForegroundColor Yellow
Set-Location backend
pip install -r requirements.txt

Write-Host ""
Write-Host "🗄️ Step 3: Creating database migrations..." -ForegroundColor Yellow
python manage.py makemigrations

Write-Host ""
Write-Host "🗄️ Step 4: Applying migrations..." -ForegroundColor Yellow
python manage.py migrate

Write-Host ""
Write-Host "👤 Step 5: Creating superuser..." -ForegroundColor Yellow
Write-Host "Please enter superuser credentials:" -ForegroundColor Cyan
python manage.py createsuperuser

Write-Host ""
Write-Host "✅ Setup Complete!" -ForegroundColor Green
Write-Host ""
Write-Host "To start the server, run:" -ForegroundColor Cyan
Write-Host "  cd backend" -ForegroundColor White
Write-Host "  python manage.py runserver" -ForegroundColor White
Write-Host ""
Write-Host "Then open frontend/login.html in your browser" -ForegroundColor Cyan
Write-Host ""
Write-Host "Admin Panel: http://localhost:8000/admin/" -ForegroundColor Yellow
Write-Host ""

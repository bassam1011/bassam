import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../hooks/useAuth';
import './Navbar.css';

export const Navbar = () => {
    const { user, logout } = useAuth();
    const navigate = useNavigate();

    const handleLogout = () => {
        logout();
    };

    return (
        <nav className="navbar glass">
            <div className="navbar-container">
                {/* Logo */}
                <Link to="/dashboard" className="navbar-logo">
                    <span className="logo-icon">🔒</span>
                    <span className="logo-text gradient-text">Security System</span>
                </Link>

                {/* Navigation Links */}
                <div className="navbar-links">
                    <Link to="/dashboard" className="nav-link">
                        <span>📊</span>
                        Dashboard
                    </Link>
                    <Link to="/wanted" className="nav-link">
                        <span>👤</span>
                        Wanted Persons
                    </Link>
                    <Link to="/alerts" className="nav-link">
                        <span>🚨</span>
                        Alerts
                    </Link>
                </div>

                {/* User Menu */}
                <div className="navbar-user">
                    <div className="user-info">
                        <div className="user-avatar">
                            {user?.username?.charAt(0).toUpperCase() || 'U'}
                        </div>
                        <div className="user-details">
                            <span className="user-name">{user?.username || 'User'}</span>
                            <span className="user-role">{user?.is_staff ? 'Admin' : 'User'}</span>
                        </div>
                    </div>
                    <button onClick={handleLogout} className="btn btn-secondary btn-sm">
                        Logout
                    </button>
                </div>
            </div>
        </nav>
    );
};

import { useEffect, useState } from 'react';
import './StatCard.css';

export const StatCard = ({
    title,
    value,
    icon,
    gradient = 'primary',
    loading = false
}) => {
    const [displayValue, setDisplayValue] = useState(0);

    // Count up animation
    useEffect(() => {
        if (loading || value === undefined) return;

        const duration = 1000;
        const steps = 30;
        const increment = value / steps;
        let current = 0;

        const timer = setInterval(() => {
            current += increment;
            if (current >= value) {
                setDisplayValue(value);
                clearInterval(timer);
            } else {
                setDisplayValue(Math.floor(current));
            }
        }, duration / steps);

        return () => clearInterval(timer);
    }, [value, loading]);

    const gradients = {
        primary: 'var(--primary-gradient)',
        secondary: 'var(--secondary-gradient)',
        success: 'var(--success-gradient)',
        danger: 'var(--danger-gradient)',
    };

    return (
        <div className="stat-card glass fade-in">
            <div
                className="stat-icon"
                style={{ background: gradients[gradient] }}
            >
                {icon}
            </div>
            <div className="stat-content">
                <div className="stat-value">
                    {loading ? (
                        <div className="spinner"></div>
                    ) : (
                        displayValue
                    )}
                </div>
                <div className="stat-title">{title}</div>
            </div>
            <div
                className="stat-decoration"
                style={{ background: gradients[gradient] }}
            ></div>
        </div>
    );
};

import { useState, useEffect } from 'react';
import { Input } from '../ui/Input';
import { Button } from '../ui/Button';
import { wantedAPI } from '../../services/api';
import toast from 'react-hot-toast';
import './WantedPersonForm.css';

export const WantedPersonForm = ({ person, onClose, onSuccess }) => {
    const [formData, setFormData] = useState({
        name: '',
        crime: '',
        description: '',
    });
    const [images, setImages] = useState([]);
    const [existingPhotos, setExistingPhotos] = useState([]);
    const [loading, setLoading] = useState(false);
    const [dragActive, setDragActive] = useState(false);

    useEffect(() => {
        if (person) {
            setFormData({
                name: person.name || '',
                crime: person.crime || '',
                description: person.description || '',
            });
            setExistingPhotos(person.photos || []);
        }
    }, [person]);

    const handleChange = (e) => {
        setFormData({
            ...formData,
            [e.target.name]: e.target.value,
        });
    };

    const handleImageSelect = (e) => {
        const files = Array.from(e.target.files);
        handleFiles(files);
    };

    const handleFiles = (files) => {
        const imageFiles = files.filter(file => file.type.startsWith('image/'));

        if (imageFiles.length !== files.length) {
            toast.error('Only image files are allowed');
        }

        setImages(prev => [...prev, ...imageFiles]);
    };

    const handleDrag = (e) => {
        e.preventDefault();
        e.stopPropagation();
        if (e.type === 'dragenter' || e.type === 'dragover') {
            setDragActive(true);
        } else if (e.type === 'dragleave') {
            setDragActive(false);
        }
    };

    const handleDrop = (e) => {
        e.preventDefault();
        e.stopPropagation();
        setDragActive(false);

        const files = Array.from(e.dataTransfer.files);
        handleFiles(files);
    };

    const removeImage = (index) => {
        setImages(prev => prev.filter((_, i) => i !== index));
    };

    const removeExistingPhoto = async (photoId) => {
        if (!window.confirm('Are you sure you want to delete this photo?')) {
            return;
        }

        try {
            await wantedAPI.deletePhoto(person.id, photoId);
            setExistingPhotos(prev => prev.filter(photo => photo.id !== photoId));
            toast.success('Photo deleted successfully');
        } catch (error) {
            console.error('Error deleting photo:', error);
            toast.error('Failed to delete photo');
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);

        try {
            const formDataToSend = new FormData();
            formDataToSend.append('name', formData.name);
            formDataToSend.append('crime', formData.crime);
            formDataToSend.append('description', formData.description);

            // Add images
            images.forEach((image) => {
                formDataToSend.append('photos', image);
            });

            if (person) {
                await wantedAPI.update(person.id, formDataToSend);
                toast.success('Wanted person updated successfully');
            } else {
                await wantedAPI.create(formDataToSend);
                toast.success('Wanted person added successfully');
            }

            onSuccess();
        } catch (error) {
            console.error('Error saving wanted person:', error);
            toast.error(error.response?.data?.detail || 'Failed to save wanted person');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="modal-overlay" onClick={onClose}>
            <div className="modal-content glass" onClick={(e) => e.stopPropagation()}>
                <div className="modal-header">
                    <h2>{person ? 'Edit Wanted Person' : 'Add Wanted Person'}</h2>
                    <button className="modal-close" onClick={onClose}>×</button>
                </div>

                <form onSubmit={handleSubmit} className="modal-form">
                    <Input
                        label="Full Name"
                        type="text"
                        name="name"
                        value={formData.name}
                        onChange={handleChange}
                        placeholder="Enter full name"
                        required
                    />

                    <Input
                        label="Crime"
                        type="text"
                        name="crime"
                        value={formData.crime}
                        onChange={handleChange}
                        placeholder="Enter crime description"
                        required
                    />

                    <div className="form-group">
                        <label className="form-label">Description</label>
                        <textarea
                            name="description"
                            value={formData.description}
                            onChange={handleChange}
                            placeholder="Additional details..."
                            className="form-input"
                            rows="4"
                        />
                    </div>

                    {/* Existing Photos */}
                    {existingPhotos.length > 0 && (
                        <div className="form-group">
                            <label className="form-label">Existing Photos</label>
                            <div className="image-preview-grid">
                                {existingPhotos.map((photo) => (
                                    <div key={photo.id} className="image-preview">
                                        <img src={photo.image} alt="Wanted person" />
                                        <button
                                            type="button"
                                            className="image-remove"
                                            onClick={() => removeExistingPhoto(photo.id)}
                                        >
                                            ×
                                        </button>
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}

                    {/* Image Upload */}
                    <div className="form-group">
                        <label className="form-label">
                            {person ? 'Add More Photos' : 'Upload Photos'}
                        </label>

                        <div
                            className={`image-upload ${dragActive ? 'drag-active' : ''}`}
                            onDragEnter={handleDrag}
                            onDragLeave={handleDrag}
                            onDragOver={handleDrag}
                            onDrop={handleDrop}
                        >
                            <input
                                type="file"
                                id="image-input"
                                multiple
                                accept="image/*"
                                onChange={handleImageSelect}
                                style={{ display: 'none' }}
                            />
                            <label htmlFor="image-input" className="upload-label">
                                <div className="upload-icon">📸</div>
                                <p>Drag & drop images here or click to browse</p>
                                <span className="upload-hint">Support: JPG, PNG, GIF</span>
                            </label>
                        </div>

                        {/* New Image Previews */}
                        {images.length > 0 && (
                            <div className="image-preview-grid">
                                {images.map((image, index) => (
                                    <div key={index} className="image-preview">
                                        <img src={URL.createObjectURL(image)} alt={`Preview ${index + 1}`} />
                                        <button
                                            type="button"
                                            className="image-remove"
                                            onClick={() => removeImage(index)}
                                        >
                                            ×
                                        </button>
                                    </div>
                                ))}
                            </div>
                        )}
                    </div>

                    <div className="modal-actions">
                        <Button type="button" variant="secondary" onClick={onClose}>
                            Cancel
                        </Button>
                        <Button type="submit" variant="primary" loading={loading}>
                            {person ? 'Update' : 'Add'} Person
                        </Button>
                    </div>
                </form>
            </div>
        </div>
    );
};

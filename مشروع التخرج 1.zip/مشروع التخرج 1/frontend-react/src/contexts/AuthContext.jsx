import { createContext, useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { authAPI } from '../services/api';
import toast from 'react-hot-toast';

export const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
    const [user, setUser] = useState(null);
    const [loading, setLoading] = useState(true);
    const navigate = useNavigate();

    // Check if user is logged in on mount
    useEffect(() => {
        const initAuth = async () => {
            const token = localStorage.getItem('access_token');
            const savedUser = localStorage.getItem('user');

            if (token && savedUser) {
                try {
                    setUser(JSON.parse(savedUser));
                    // Optionally verify token by fetching profile
                    const response = await authAPI.getProfile();
                    setUser(response.data);
                    localStorage.setItem('user', JSON.stringify(response.data));
                } catch (error) {
                    console.error('Auth verification failed:', error);
                    logout();
                }
            }
            setLoading(false);
        };

        initAuth();
    }, []);

    const login = async (credentials) => {
        try {
            const response = await authAPI.login(credentials);
            const { access, refresh, user: userData } = response.data;

            // Save tokens and user data
            localStorage.setItem('access_token', access);
            localStorage.setItem('refresh_token', refresh);
            localStorage.setItem('user', JSON.stringify(userData));

            setUser(userData);
            toast.success(`Welcome back, ${userData.username}!`);
            navigate('/dashboard');

            return { success: true };
        } catch (error) {
            const errorMessage = error.response?.data?.detail ||
                error.response?.data?.error ||
                'Login failed. Please check your credentials.';
            toast.error(errorMessage);
            return { success: false, error: errorMessage };
        }
    };

    const register = async (userData) => {
        try {
            const response = await authAPI.register(userData);
            toast.success('Registration request submitted! Please wait for admin approval.');
            navigate('/login');
            return { success: true, data: response.data };
        } catch (error) {
            const errorMessage = error.response?.data?.detail ||
                error.response?.data?.error ||
                'Registration failed. Please try again.';
            toast.error(errorMessage);
            return { success: false, error: errorMessage };
        }
    };

    const logout = () => {
        authAPI.logout();
        setUser(null);
        toast.success('Logged out successfully');
        navigate('/login');
    };

    const value = {
        user,
        loading,
        login,
        register,
        logout,
        isAuthenticated: !!user,
    };

    return (
        <AuthContext.Provider value={value}>
            {children}
        </AuthContext.Provider>
    );
};

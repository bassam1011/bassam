import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Navbar } from '../components/layout/Navbar';
import { StatCard } from '../components/dashboard/StatCard';
import { Button } from '../components/ui/Button';
import { wantedAPI, alertsAPI } from '../services/api';
import './Dashboard.css';

export const Dashboard = () => {
    const [stats, setStats] = useState({
        wantedCount: 0,
        totalAlerts: 0,
        pendingAlerts: 0,
    });
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        loadDashboardData();
    }, []);

    const loadDashboardData = async () => {
        try {
            setLoading(true);

            // Fetch all data in parallel
            const [wantedResponse, alertsResponse, pendingResponse] = await Promise.all([
                wantedAPI.getAll(),
                alertsAPI.getAll(),
                alertsAPI.getAll({ status: 'pending' }),
            ]);

            setStats({
                wantedCount: wantedResponse.data.count || wantedResponse.data.length || 0,
                totalAlerts: alertsResponse.data.count || alertsResponse.data.length || 0,
                pendingAlerts: pendingResponse.data.count || pendingResponse.data.length || 0,
            });
        } catch (error) {
            console.error('Error loading dashboard data:', error);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="dashboard-page">
            <Navbar />

            <div className="container">
                {/* Header */}
                <div className="dashboard-header fade-in">
                    <div>
                        <h1 className="dashboard-title">Dashboard</h1>
                        <p className="dashboard-subtitle">Welcome to your security management system</p>
                    </div>
                </div>

                {/* Statistics Grid */}
                <div className="stats-grid">
                    <StatCard
                        title="Wanted Persons"
                        value={stats.wantedCount}
                        icon="👤"
                        gradient="primary"
                        loading={loading}
                    />
                    <StatCard
                        title="Total Alerts"
                        value={stats.totalAlerts}
                        icon="🚨"
                        gradient="secondary"
                        loading={loading}
                    />
                    <StatCard
                        title="Pending Alerts"
                        value={stats.pendingAlerts}
                        icon="⏳"
                        gradient="danger"
                        loading={loading}
                    />
                </div>

                {/* Quick Actions */}
                <div className="quick-actions glass fade-in">
                    <h2 className="section-title">Quick Actions</h2>
                    <div className="actions-grid">
                        <Link to="/wanted" className="action-card">
                            <div className="action-icon" style={{ background: 'var(--primary-gradient)' }}>
                                👤
                            </div>
                            <div className="action-content">
                                <h3>Manage Wanted Persons</h3>
                                <p>Add, edit, or remove wanted persons from the database</p>
                            </div>
                            <div className="action-arrow">→</div>
                        </Link>

                        <Link to="/alerts" className="action-card">
                            <div className="action-icon" style={{ background: 'var(--secondary-gradient)' }}>
                                🚨
                            </div>
                            <div className="action-content">
                                <h3>View Alerts</h3>
                                <p>Review and manage face recognition alerts</p>
                            </div>
                            <div className="action-arrow">→</div>
                        </Link>
                    </div>
                </div>

                {/* Recent Activity Section (Optional - can be expanded later) */}
                <div className="recent-activity glass fade-in">
                    <h2 className="section-title">System Status</h2>
                    <div className="status-items">
                        <div className="status-item">
                            <div className="status-indicator status-online"></div>
                            <span>Face Recognition System: Online</span>
                        </div>
                        <div className="status-item">
                            <div className="status-indicator status-online"></div>
                            <span>Database: Connected</span>
                        </div>
                        <div className="status-item">
                            <div className="status-indicator status-online"></div>
                            <span>API Services: Running</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

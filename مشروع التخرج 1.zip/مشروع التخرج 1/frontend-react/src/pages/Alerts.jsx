import { useState, useEffect } from 'react';
import { Navbar } from '../components/layout/Navbar';
import { Button } from '../components/ui/Button';
import { Card } from '../components/ui/Card';
import { alertsAPI } from '../services/api';
import toast from 'react-hot-toast';
import './Alerts.css';

export const Alerts = () => {
    const [alerts, setAlerts] = useState([]);
    const [loading, setLoading] = useState(true);
    const [statusFilter, setStatusFilter] = useState('all');
    const [dateRange, setDateRange] = useState({ start: '', end: '' });

    useEffect(() => {
        loadAlerts();
    }, [statusFilter, dateRange]);

    const loadAlerts = async () => {
        try {
            setLoading(true);
            const params = {};

            if (statusFilter !== 'all') {
                params.status = statusFilter;
            }

            if (dateRange.start) {
                params.start_date = dateRange.start;
            }

            if (dateRange.end) {
                params.end_date = dateRange.end;
            }

            const response = await alertsAPI.getAll(params);
            setAlerts(response.data.results || response.data || []);
        } catch (error) {
            console.error('Error loading alerts:', error);
            toast.error('Failed to load alerts');
        } finally {
            setLoading(false);
        }
    };

    const handleConfirm = async (id) => {
        try {
            await alertsAPI.confirm(id);
            toast.success('Alert confirmed');
            loadAlerts();
        } catch (error) {
            console.error('Error confirming alert:', error);
            toast.error('Failed to confirm alert');
        }
    };

    const handleReject = async (id) => {
        try {
            await alertsAPI.reject(id);
            toast.success('Alert rejected');
            loadAlerts();
        } catch (error) {
            console.error('Error rejecting alert:', error);
            toast.error('Failed to reject alert');
        }
    };

    const getStatusBadge = (status) => {
        const badges = {
            pending: { text: 'Pending', class: 'status-pending' },
            confirmed: { text: 'Confirmed', class: 'status-confirmed' },
            rejected: { text: 'Rejected', class: 'status-rejected' },
        };
        return badges[status] || badges.pending;
    };

    return (
        <div className="alerts-page">
            <Navbar />

            <div className="container">
                {/* Header */}
                <div className="page-header fade-in">
                    <div>
                        <h1 className="page-title">Alerts</h1>
                        <p className="page-subtitle">Manage face recognition alerts</p>
                    </div>
                </div>

                {/* Filters */}
                <div className="filters-container glass">
                    <div className="filter-group">
                        <label className="filter-label">Status</label>
                        <select
                            value={statusFilter}
                            onChange={(e) => setStatusFilter(e.target.value)}
                            className="filter-select"
                        >
                            <option value="all">All Alerts</option>
                            <option value="pending">Pending</option>
                            <option value="confirmed">Confirmed</option>
                            <option value="rejected">Rejected</option>
                        </select>
                    </div>

                    <div className="filter-group">
                        <label className="filter-label">Start Date</label>
                        <input
                            type="date"
                            value={dateRange.start}
                            onChange={(e) => setDateRange({ ...dateRange, start: e.target.value })}
                            className="filter-input"
                        />
                    </div>

                    <div className="filter-group">
                        <label className="filter-label">End Date</label>
                        <input
                            type="date"
                            value={dateRange.end}
                            onChange={(e) => setDateRange({ ...dateRange, end: e.target.value })}
                            className="filter-input"
                        />
                    </div>

                    <Button
                        onClick={() => {
                            setStatusFilter('all');
                            setDateRange({ start: '', end: '' });
                        }}
                        variant="secondary"
                        size="sm"
                    >
                        Clear Filters
                    </Button>
                </div>

                {/* Alerts List */}
                {loading ? (
                    <div className="loading-container">
                        <div className="spinner" style={{ width: '40px', height: '40px' }}></div>
                        <p>Loading alerts...</p>
                    </div>
                ) : alerts.length === 0 ? (
                    <div className="empty-state glass">
                        <div className="empty-icon">🚨</div>
                        <h3>No alerts found</h3>
                        <p>Try adjusting your filters or check back later</p>
                    </div>
                ) : (
                    <div className="alerts-list">
                        {alerts.map((alert, index) => {
                            const statusBadge = getStatusBadge(alert.status);
                            return (
                                <Card key={alert.id} className="alert-card fade-in" style={{ animationDelay: `${index * 0.05}s` }}>
                                    <div className="alert-header">
                                        <div className="alert-info">
                                            <h3 className="alert-title">
                                                Alert #{alert.id}
                                            </h3>
                                            <span className={`status-badge ${statusBadge.class}`}>
                                                {statusBadge.text}
                                            </span>
                                        </div>
                                        <div className="alert-time">
                                            📅 {new Date(alert.timestamp).toLocaleString()}
                                        </div>
                                    </div>

                                    <div className="alert-content">
                                        {alert.wanted_person && (
                                            <div className="alert-person">
                                                <div className="person-avatar">
                                                    {alert.wanted_person.photos && alert.wanted_person.photos.length > 0 ? (
                                                        <img src={alert.wanted_person.photos[0].image} alt={alert.wanted_person.name} />
                                                    ) : (
                                                        <div className="avatar-placeholder">👤</div>
                                                    )}
                                                </div>
                                                <div className="person-details">
                                                    <h4>{alert.wanted_person.name}</h4>
                                                    <p className="person-crime">{alert.wanted_person.crime}</p>
                                                </div>
                                            </div>
                                        )}

                                        {alert.location && (
                                            <div className="alert-location">
                                                📍 Location: {alert.location}
                                            </div>
                                        )}

                                        {alert.confidence_score && (
                                            <div className="alert-confidence">
                                                <span>Confidence Score:</span>
                                                <div className="confidence-bar">
                                                    <div
                                                        className="confidence-fill"
                                                        style={{ width: `${alert.confidence_score * 100}%` }}
                                                    ></div>
                                                </div>
                                                <span>{(alert.confidence_score * 100).toFixed(1)}%</span>
                                            </div>
                                        )}
                                    </div>

                                    {alert.status === 'pending' && (
                                        <div className="alert-actions">
                                            <Button
                                                onClick={() => handleConfirm(alert.id)}
                                                variant="success"
                                                size="sm"
                                            >
                                                ✓ Confirm
                                            </Button>
                                            <Button
                                                onClick={() => handleReject(alert.id)}
                                                variant="danger"
                                                size="sm"
                                            >
                                                ✗ Reject
                                            </Button>
                                        </div>
                                    )}
                                </Card>
                            );
                        })}
                    </div>
                )}
            </div>
        </div>
    );
};

import { useState, useEffect } from 'react';
import { Navbar } from '../components/layout/Navbar';
import { Button } from '../components/ui/Button';
import { Card } from '../components/ui/Card';
import { wantedAPI } from '../services/api';
import { WantedPersonForm } from '../components/wanted/WantedPersonForm';
import toast from 'react-hot-toast';
import './WantedPersons.css';

export const WantedPersons = () => {
    const [persons, setPersons] = useState([]);
    const [loading, setLoading] = useState(true);
    const [showForm, setShowForm] = useState(false);
    const [editingPerson, setEditingPerson] = useState(null);
    const [searchTerm, setSearchTerm] = useState('');

    useEffect(() => {
        loadPersons();
    }, []);

    const loadPersons = async () => {
        try {
            setLoading(true);
            const response = await wantedAPI.getAll();
            setPersons(response.data.results || response.data || []);
        } catch (error) {
            console.error('Error loading wanted persons:', error);
            toast.error('Failed to load wanted persons');
        } finally {
            setLoading(false);
        }
    };

    const handleAdd = () => {
        setEditingPerson(null);
        setShowForm(true);
    };

    const handleEdit = (person) => {
        setEditingPerson(person);
        setShowForm(true);
    };

    const handleDelete = async (id) => {
        if (!window.confirm('Are you sure you want to delete this person?')) {
            return;
        }

        try {
            await wantedAPI.delete(id);
            toast.success('Person deleted successfully');
            loadPersons();
        } catch (error) {
            console.error('Error deleting person:', error);
            toast.error('Failed to delete person');
        }
    };

    const handleFormClose = () => {
        setShowForm(false);
        setEditingPerson(null);
    };

    const handleFormSuccess = () => {
        setShowForm(false);
        setEditingPerson(null);
        loadPersons();
    };

    const filteredPersons = persons.filter(person =>
        person.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        person.crime?.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <div className="wanted-page">
            <Navbar />

            <div className="container">
                {/* Header */}
                <div className="page-header fade-in">
                    <div>
                        <h1 className="page-title">Wanted Persons</h1>
                        <p className="page-subtitle">Manage the database of wanted individuals</p>
                    </div>
                    <Button onClick={handleAdd} variant="primary">
                        + Add Wanted Person
                    </Button>
                </div>

                {/* Search Bar */}
                <div className="search-bar glass">
                    <span className="search-icon">🔍</span>
                    <input
                        type="text"
                        placeholder="Search by name or crime..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="search-input"
                    />
                </div>

                {/* Persons Grid */}
                {loading ? (
                    <div className="loading-container">
                        <div className="spinner" style={{ width: '40px', height: '40px' }}></div>
                        <p>Loading wanted persons...</p>
                    </div>
                ) : filteredPersons.length === 0 ? (
                    <div className="empty-state glass">
                        <div className="empty-icon">👤</div>
                        <h3>No wanted persons found</h3>
                        <p>
                            {searchTerm
                                ? 'Try adjusting your search terms'
                                : 'Click the button above to add your first wanted person'}
                        </p>
                    </div>
                ) : (
                    <div className="persons-grid">
                        {filteredPersons.map((person, index) => (
                            <Card key={person.id} className="person-card fade-in" style={{ animationDelay: `${index * 0.1}s` }}>
                                <div className="person-image">
                                    {person.photos && person.photos.length > 0 ? (
                                        <img src={person.photos[0].image} alt={person.name} />
                                    ) : (
                                        <div className="person-placeholder">👤</div>
                                    )}
                                </div>
                                <div className="person-info">
                                    <h3 className="person-name">{person.name}</h3>
                                    <p className="person-crime">
                                        <span className="crime-badge">{person.crime || 'No crime specified'}</span>
                                    </p>
                                    {person.description && (
                                        <p className="person-description">{person.description}</p>
                                    )}
                                    <div className="person-meta">
                                        <span>📸 {person.photos?.length || 0} photos</span>
                                        <span>📅 {new Date(person.created_at).toLocaleDateString()}</span>
                                    </div>
                                </div>
                                <div className="person-actions">
                                    <Button onClick={() => handleEdit(person)} variant="secondary" size="sm">
                                        Edit
                                    </Button>
                                    <Button onClick={() => handleDelete(person.id)} variant="danger" size="sm">
                                        Delete
                                    </Button>
                                </div>
                            </Card>
                        ))}
                    </div>
                )}
            </div>

            {/* Form Modal */}
            {showForm && (
                <WantedPersonForm
                    person={editingPerson}
                    onClose={handleFormClose}
                    onSuccess={handleFormSuccess}
                />
            )}
        </div>
    );
};

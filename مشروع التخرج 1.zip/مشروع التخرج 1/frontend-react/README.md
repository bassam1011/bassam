# Security System - React Frontend

A modern, professional React-based frontend for the Security Management System with premium design and enhanced user experience.

## ✨ Features

### 🎨 Premium Design
- **Glassmorphism Effects**: Modern glass-like UI components with backdrop blur
- **Gradient Backgrounds**: Vibrant, animated gradient backgrounds
- **Smooth Animations**: Micro-animations and transitions throughout
- **Responsive Design**: Mobile-first approach, works on all devices
- **Modern Typography**: Inter font family for clean, professional look

### 🔐 Authentication
- Login with JWT token management
- Registration with admin approval workflow
- Automatic token refresh
- Protected routes

### 📊 Dashboard
- Real-time statistics with count-up animations
- Quick action cards
- System status indicators
- Responsive grid layout

### 👤 Wanted Persons Management
- Add, edit, and delete wanted persons
- Multi-image upload with drag & drop
- Search and filter functionality
- Image preview and management
- Detailed person cards

### 🚨 Alerts Management
- View all face recognition alerts
- Filter by status (pending/confirmed/rejected)
- Date range filtering
- Confirm/reject actions
- Confidence score visualization

## 🚀 Quick Start

### Prerequisites
- Node.js 16+ and npm
- Django backend running on http://localhost:8000

### Installation

```bash
# Navigate to the frontend-react directory
cd frontend-react

# Install dependencies
npm install

# Start development server
npm run dev
```

The application will be available at http://localhost:5173

### Build for Production

```bash
npm run build
npm run preview
```

## 📁 Project Structure

```
frontend-react/
├── src/
│   ├── components/
│   │   ├── layout/
│   │   │   ├── Navbar.jsx          # Navigation bar
│   │   │   └── Navbar.css
│   │   ├── dashboard/
│   │   │   ├── StatCard.jsx        # Statistics card with animation
│   │   │   └── StatCard.css
│   │   ├── wanted/
│   │   │   ├── WantedPersonForm.jsx # Add/Edit form with image upload
│   │   │   └── WantedPersonForm.css
│   │   ├── ui/
│   │   │   ├── Button.jsx          # Reusable button component
│   │   │   ├── Input.jsx           # Form input component
│   │   │   └── Card.jsx            # Card component
│   │   └── ProtectedRoute.jsx      # Route guard
│   ├── contexts/
│   │   └── AuthContext.jsx         # Authentication context
│   ├── hooks/
│   │   └── useAuth.js              # Auth hook
│   ├── pages/
│   │   ├── Login.jsx               # Login page
│   │   ├── Register.jsx            # Registration page
│   │   ├── Dashboard.jsx           # Main dashboard
│   │   ├── WantedPersons.jsx       # Wanted persons list
│   │   └── Alerts.jsx              # Alerts management
│   ├── services/
│   │   └── api.js                  # API service layer
│   ├── App.jsx                     # Main app component
│   ├── main.jsx                    # Entry point
│   └── index.css                   # Global styles
├── index.html
├── package.json
└── vite.config.js
```

## 🔌 API Integration

The frontend connects to the Django backend API at `http://localhost:8000/api`. Make sure CORS is enabled in your Django settings:

```python
CORS_ALLOWED_ORIGINS = [
    "http://localhost:5173",
]
```

### API Endpoints Used

- `POST /api/auth/login/` - User login
- `POST /api/auth/register/` - User registration
- `GET /api/auth/profile/` - Get user profile
- `GET /api/wanted/` - List wanted persons
- `POST /api/wanted/` - Create wanted person
- `PUT /api/wanted/{id}/` - Update wanted person
- `DELETE /api/wanted/{id}/` - Delete wanted person
- `GET /api/alerts/` - List alerts (with filters)
- `PUT /api/alerts/{id}/confirm/` - Confirm alert
- `PUT /api/alerts/{id}/reject/` - Reject alert

## 🎨 Design System

### Colors
- **Primary**: Purple gradient (#667eea → #764ba2)
- **Secondary**: Pink gradient (#f093fb → #f5576c)
- **Success**: Blue gradient (#4facfe → #00f2fe)
- **Danger**: Pink-yellow gradient (#fa709a → #fee140)

### Components
- All components use glassmorphism with backdrop blur
- Consistent spacing and border radius
- Smooth transitions (250ms cubic-bezier)
- Hover effects on interactive elements

## 📱 Responsive Breakpoints

- **Desktop**: 1280px+
- **Tablet**: 768px - 1279px
- **Mobile**: < 768px

## 🛠️ Technologies Used

- **React 18**: Latest React with hooks
- **Vite**: Fast build tool and dev server
- **React Router**: Client-side routing
- **TanStack Query**: Data fetching and caching
- **Axios**: HTTP client with interceptors
- **React Hot Toast**: Toast notifications
- **Framer Motion**: Animations (ready to use)

## 🔧 Development

### Available Scripts

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm run preview` - Preview production build

### Environment Variables

Create a `.env` file (already gitignored):

```
VITE_API_URL=http://localhost:8000/api
```

## 📝 Notes

- All forms include validation and error handling
- Images are uploaded as multipart/form-data
- JWT tokens are stored in localStorage
- Automatic token refresh on 401 responses
- Toast notifications for all user actions

## 🎯 Future Enhancements

- Dark mode toggle (infrastructure ready)
- Real-time notifications with WebSockets
- Advanced search with filters
- Export data functionality
- User profile management
- Activity logs

## 📄 License

This project is for educational purposes.

# نظام الأمان - واجهة React الاحترافية

## 🚀 البدء السريع

### 1. تثبيت المكتبات

**مهم**: بسبب قيود PowerShell، استخدم Command Prompt:

```cmd
cd "C:\Users\User1\Desktop\مشروع التخرج\frontend-react"
npm install
```

### 2. تشغيل التطبيق

```cmd
npm run dev
```

التطبيق سيعمل على: **http://localhost:5173**

### 3. تأكد من تشغيل Backend

```cmd
cd "C:\Users\User1\Desktop\مشروع التخرج\backend"
python manage.py runserver
```

## ✨ الميزات

- 🔐 تسجيل دخول وتسجيل مستخدمين جدد
- 📊 لوحة تحكم مع إحصائيات متحركة
- 👤 إدارة المطلوبين مع رفع صور متعدد
- 🚨 إدارة التنبيهات مع فلترة
- 🎨 تصميم Glassmorphism احترافي
- 📱 متجاوب لجميع الأجهزة

## 📝 ملاحظات

- استخدم Command Prompt بدلاً من PowerShell
- تأكد من تشغيل Backend قبل Frontend
- أنشئ مستخدم عبر Django admin للاختبار

للمزيد من التفاصيل، راجع [README.md](README.md) أو [walkthrough.md](../../../.gemini/antigravity/brain/8df57e53-26b2-42d0-9315-761c647f4a24/walkthrough.md)

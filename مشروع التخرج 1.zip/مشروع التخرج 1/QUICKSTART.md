# Quick Start Guide

## 🚀 الطريقة السريعة

### 1. إعداد قاعدة البيانات
```bash
# افتح PostgreSQL
psql -U postgres

# أنشئ قاعدة البيانات
CREATE DATABASE security_db;

# اخرج
\q
```

### 2. تشغيل Setup Script (Windows)
```powershell
.\setup.ps1
```

أو يدوياً:
```bash
cd backend
pip install -r requirements.txt
python manage.py makemigrations
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```

### 3. فتح Frontend
افتح `frontend/login.html` في المتصفح

---

## 📝 بيانات الاختبار

### تسجيل الدخول
استخدم بيانات superuser التي أنشأتها

### إضافة مطلوب
1. اذهب إلى Dashboard
2. اضغط "Manage Wanted Persons"
3. اضغط "+ Add Wanted Person"
4. املأ البيانات:
   - Name: John Doe
   - National ID: 123456789
   - Danger Level: High
   - Description: Test wanted person
   - Photos: ارفع صورة أو أكثر

### إضافة تنبيه (للاختبار)
استخدم Admin Panel:
1. اذهب إلى `http://localhost:8000/admin/`
2. اختر Alerts → Add Alert
3. اختر wanted person
4. ارفع صورة
5. أدخل similarity score (مثلاً 85.5)
6. احفظ

ثم اذهب إلى `frontend/alerts.html` لمراجعة التنبيه

---

## 🔗 روابط مهمة

- **Frontend**: `frontend/login.html`
- **Backend API**: `http://localhost:8000/api/`
- **Admin Panel**: `http://localhost:8000/admin/`
- **API Docs**: راجع [README.md](README.md)

---

## ❓ مشاكل شائعة

### خطأ في الاتصال بقاعدة البيانات
```
django.db.utils.OperationalError: could not connect to server
```
**الحل**: تأكد من تشغيل PostgreSQL

### خطأ CORS
```
Access to fetch at 'http://localhost:8000/api/...' has been blocked by CORS policy
```
**الحل**: تأكد من تشغيل Backend على port 8000

### الصور لا تظهر
**الحل**: تأكد من إعدادات MEDIA في settings.py وأن مجلد media/ موجود

---

## 📞 الدعم

راجع [README.md](README.md) للتفاصيل الكاملة

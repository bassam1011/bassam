from django.contrib import admin
from .models import RegistrationRequest


@admin.register(RegistrationRequest)
class RegistrationRequestAdmin(admin.ModelAdmin):
    list_display = ['username', 'email', 'full_name', 'status', 'created_at']
    list_filter = ['status', 'created_at']
    search_fields = ['username', 'email', 'full_name']
    readonly_fields = ['created_at', 'password']
    
    fieldsets = (
        ('User Information', {
            'fields': ('full_name', 'email', 'username', 'password')
        }),
        ('Status', {
            'fields': ('status', 'reviewed_by', 'reviewed_at')
        }),
        ('Timestamps', {
            'fields': ('created_at',)
        }),
    )

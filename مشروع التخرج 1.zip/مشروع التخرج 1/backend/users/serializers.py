from rest_framework import serializers
from django.contrib.auth.models import User
from django.contrib.auth.hashers import make_password
from .models import RegistrationRequest


class UserSerializer(serializers.ModelSerializer):
    """Serializer for User model"""
    
    class Meta:
        model = User
        fields = ['id', 'username', 'email', 'first_name', 'last_name', 'is_staff']
        read_only_fields = ['id', 'is_staff']


class LoginSerializer(serializers.Serializer):
    """Serializer for login credentials"""
    username = serializers.CharField()
    password = serializers.CharField(write_only=True)


class RegistrationRequestSerializer(serializers.ModelSerializer):
    """Serializer for registration requests"""
    
    class Meta:
        model = RegistrationRequest
        fields = ['id', 'full_name', 'email', 'username', 'password', 'status', 'created_at']
        read_only_fields = ['id', 'status', 'created_at']
        extra_kwargs = {
            'password': {'write_only': True}
        }
    
    def create(self, validated_data):
        # Hash the password before saving
        validated_data['password'] = make_password(validated_data['password'])
        return super().create(validated_data)

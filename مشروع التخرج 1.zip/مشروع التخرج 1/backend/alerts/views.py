from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework.parsers import MultiPartParser, FormParser
from django.utils import timezone
from .models import Alert
from .serializers import AlertSerializer, AlertUpdateSerializer


class AlertViewSet(viewsets.ModelViewSet):
    """
    ViewSet for managing alerts
    
    Endpoints:
    - GET /api/alerts/ - List all alerts (with filtering)
    - POST /api/alerts/ - Create new alert
    - GET /api/alerts/{id}/ - Retrieve one alert
    - PUT /api/alerts/{id}/ - Update alert status
    - DELETE /api/alerts/{id}/ - Delete alert
    - PUT /api/alerts/{id}/confirm/ - Confirm alert
    - PUT /api/alerts/{id}/reject/ - Reject alert
    """
    queryset = Alert.objects.all()
    serializer_class = AlertSerializer
    permission_classes = [IsAuthenticated]
    parser_classes = [MultiPartParser, FormParser]
    
    def get_queryset(self):
        queryset = Alert.objects.all()
        
        # Filter by status
        status_filter = self.request.query_params.get('status', None)
        if status_filter:
            queryset = queryset.filter(status=status_filter)
        
        # Filter by date range
        start_date = self.request.query_params.get('start_date', None)
        end_date = self.request.query_params.get('end_date', None)
        
        if start_date:
            queryset = queryset.filter(timestamp__gte=start_date)
        if end_date:
            queryset = queryset.filter(timestamp__lte=end_date)
        
        # Filter by wanted person
        wanted_person_id = self.request.query_params.get('wanted_person', None)
        if wanted_person_id:
            queryset = queryset.filter(wanted_person_id=wanted_person_id)
        
        return queryset
    
    def update(self, request, *args, **kwargs):
        """Update alert status"""
        instance = self.get_object()
        serializer = AlertUpdateSerializer(instance, data=request.data, partial=True)
        
        if serializer.is_valid():
            # Set reviewed metadata
            serializer.save(
                reviewed_by=request.user,
                reviewed_at=timezone.now()
            )
            
            # Return full alert data
            return Response(AlertSerializer(instance).data)
        
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
    @action(detail=True, methods=['put'])
    def confirm(self, request, pk=None):
        """Confirm an alert"""
        alert = self.get_object()
        alert.status = 'confirmed'
        alert.reviewed_by = request.user
        alert.reviewed_at = timezone.now()
        alert.save()
        
        serializer = AlertSerializer(alert)
        return Response(serializer.data)
    
    @action(detail=True, methods=['put'])
    def reject(self, request, pk=None):
        """Reject an alert"""
        alert = self.get_object()
        alert.status = 'rejected'
        alert.reviewed_by = request.user
        alert.reviewed_at = timezone.now()
        alert.save()
        
        serializer = AlertSerializer(alert)
        return Response(serializer.data)

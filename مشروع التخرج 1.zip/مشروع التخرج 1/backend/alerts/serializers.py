from rest_framework import serializers
from .models import Alert
from wanted.serializers import WantedPersonSerializer


class AlertSerializer(serializers.ModelSerializer):
    """Serializer for alerts with wanted person details"""
    wanted_person_details = WantedPersonSerializer(source='wanted_person', read_only=True)
    reviewed_by_username = serializers.CharField(source='reviewed_by.username', read_only=True)
    
    class Meta:
        model = Alert
        fields = [
            'id', 'wanted_person', 'wanted_person_details', 'detected_image',
            'similarity_score', 'location', 'timestamp', 'status',
            'reviewed_by', 'reviewed_by_username', 'reviewed_at', 'notes'
        ]
        read_only_fields = ['id', 'timestamp', 'reviewed_by', 'reviewed_at']


class AlertUpdateSerializer(serializers.ModelSerializer):
    """Serializer for updating alert status"""
    
    class Meta:
        model = Alert
        fields = ['status', 'notes']
    
    def validate_status(self, value):
        if value not in ['pending', 'confirmed', 'rejected']:
            raise serializers.ValidationError("Invalid status")
        return value

from django.db import models
from django.contrib.auth.models import User
from wanted.models import WantedPerson


class Alert(models.Model):
    """Model for face recognition alerts"""
    
    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('confirmed', 'Confirmed'),
        ('rejected', 'Rejected'),
    ]
    
    wanted_person = models.ForeignKey(WantedPerson, on_delete=models.CASCADE, related_name='alerts')
    detected_image = models.ImageField(upload_to='alert_images/')
    similarity_score = models.FloatField(help_text='Similarity percentage (0-100)')
    location = models.CharField(max_length=255, blank=True)
    timestamp = models.DateTimeField(auto_now_add=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    reviewed_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='reviewed_alerts')
    reviewed_at = models.DateTimeField(null=True, blank=True)
    notes = models.TextField(blank=True)
    
    class Meta:
        ordering = ['-timestamp']
        verbose_name = 'Alert'
        verbose_name_plural = 'Alerts'
    
    def __str__(self):
        return f"Alert for {self.wanted_person.name} - {self.status}"

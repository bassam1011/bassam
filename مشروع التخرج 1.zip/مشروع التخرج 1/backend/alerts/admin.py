from django.contrib import admin
from .models import Alert


@admin.register(Alert)
class AlertAdmin(admin.ModelAdmin):
    list_display = ['wanted_person', 'similarity_score', 'status', 'timestamp', 'reviewed_by']
    list_filter = ['status', 'timestamp']
    search_fields = ['wanted_person__name', 'location']
    readonly_fields = ['timestamp', 'reviewed_at']
    
    fieldsets = (
        ('Alert Information', {
            'fields': ('wanted_person', 'detected_image', 'similarity_score', 'location')
        }),
        ('Status', {
            'fields': ('status', 'notes')
        }),
        ('Review Information', {
            'fields': ('reviewed_by', 'reviewed_at')
        }),
        ('Timestamps', {
            'fields': ('timestamp',)
        }),
    )

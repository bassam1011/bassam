from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework.parsers import MultiPartParser, FormParser
from .models import WantedPerson, WantedPersonPhoto
from .serializers import WantedPersonSerializer, WantedPersonPhotoSerializer


class WantedPersonViewSet(viewsets.ModelViewSet):
    """
    ViewSet for managing wanted persons
    
    Endpoints:
    - GET /api/wanted/ - List all wanted persons
    - POST /api/wanted/ - Create new wanted person
    - GET /api/wanted/{id}/ - Retrieve one wanted person
    - PUT /api/wanted/{id}/ - Update wanted person
    - DELETE /api/wanted/{id}/ - Delete wanted person
    - DELETE /api/wanted/{id}/delete_photo/{photo_id}/ - Delete specific photo
    """
    queryset = WantedPerson.objects.all()
    serializer_class = WantedPersonSerializer
    permission_classes = [IsAuthenticated]
    parser_classes = [MultiPartParser, FormParser]
    
    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user)
    
    @action(detail=True, methods=['delete'], url_path='delete_photo/(?P<photo_id>[^/.]+)')
    def delete_photo(self, request, pk=None, photo_id=None):
        """Delete a specific photo from a wanted person"""
        try:
            wanted_person = self.get_object()
            photo = WantedPersonPhoto.objects.get(id=photo_id, wanted_person=wanted_person)
            photo.delete()
            return Response({'message': 'Photo deleted successfully'}, status=status.HTTP_200_OK)
        except WantedPersonPhoto.DoesNotExist:
            return Response({'error': 'Photo not found'}, status=status.HTTP_404_NOT_FOUND)

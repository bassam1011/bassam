from django.apps import AppConfig


class WantedConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'wanted'

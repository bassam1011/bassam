from rest_framework import serializers
from .models import WantedPerson, WantedPersonPhoto


class WantedPersonPhotoSerializer(serializers.ModelSerializer):
    """Serializer for wanted person photos"""
    
    class Meta:
        model = WantedPersonPhoto
        fields = ['id', 'photo', 'uploaded_at']
        read_only_fields = ['id', 'uploaded_at']


class WantedPersonSerializer(serializers.ModelSerializer):
    """Serializer for wanted persons"""
    photos = WantedPersonPhotoSerializer(many=True, read_only=True)
    uploaded_photos = serializers.ListField(
        child=serializers.ImageField(),
        write_only=True,
        required=False
    )
    created_by_username = serializers.CharField(source='created_by.username', read_only=True)
    
    class Meta:
        model = WantedPerson
        fields = [
            'id', 'name', 'national_id', 'danger_level', 'description',
            'created_at', 'updated_at', 'created_by', 'created_by_username',
            'photos', 'uploaded_photos'
        ]
        read_only_fields = ['id', 'created_at', 'updated_at', 'created_by']
    
    def create(self, validated_data):
        uploaded_photos = validated_data.pop('uploaded_photos', [])
        wanted_person = WantedPerson.objects.create(**validated_data)
        
        # Create photo objects
        for photo in uploaded_photos:
            WantedPersonPhoto.objects.create(wanted_person=wanted_person, photo=photo)
        
        return wanted_person
    
    def update(self, instance, validated_data):
        uploaded_photos = validated_data.pop('uploaded_photos', [])
        
        # Update wanted person fields
        for attr, value in validated_data.items():
            setattr(instance, attr, value)
        instance.save()
        
        # Add new photos
        for photo in uploaded_photos:
            WantedPersonPhoto.objects.create(wanted_person=instance, photo=photo)
        
        return instance

from django.db import models
from django.contrib.auth.models import User


class WantedPerson(models.Model):
    """Model for wanted persons"""
    
    DANGER_LEVELS = [
        ('low', 'Low'),
        ('medium', 'Medium'),
        ('high', 'High'),
        ('critical', 'Critical'),
    ]
    
    name = models.CharField(max_length=255)
    national_id = models.CharField(max_length=50, unique=True)
    danger_level = models.CharField(max_length=20, choices=DANGER_LEVELS, default='medium')
    description = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    created_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name='wanted_persons')
    
    class Meta:
        ordering = ['-created_at']
        verbose_name = 'Wanted Person'
        verbose_name_plural = 'Wanted Persons'
    
    def __str__(self):
        return f"{self.name} ({self.national_id})"


class WantedPersonPhoto(models.Model):
    """Model for wanted person photos"""
    
    wanted_person = models.ForeignKey(WantedPerson, on_delete=models.CASCADE, related_name='photos')
    photo = models.ImageField(upload_to='wanted_photos/')
    uploaded_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        ordering = ['-uploaded_at']
        verbose_name = 'Wanted Person Photo'
        verbose_name_plural = 'Wanted Person Photos'
    
    def __str__(self):
        return f"Photo for {self.wanted_person.name}"

from django.contrib import admin
from .models import WantedPerson, WantedPersonPhoto


class WantedPersonPhotoInline(admin.TabularInline):
    model = WantedPersonPhoto
    extra = 1
    readonly_fields = ['uploaded_at']


@admin.register(WantedPerson)
class WantedPersonAdmin(admin.ModelAdmin):
    list_display = ['name', 'national_id', 'danger_level', 'created_by', 'created_at']
    list_filter = ['danger_level', 'created_at']
    search_fields = ['name', 'national_id']
    readonly_fields = ['created_at', 'updated_at']
    inlines = [WantedPersonPhotoInline]
    
    fieldsets = (
        ('Personal Information', {
            'fields': ('name', 'national_id', 'danger_level')
        }),
        ('Details', {
            'fields': ('description',)
        }),
        ('Metadata', {
            'fields': ('created_by', 'created_at', 'updated_at')
        }),
    )

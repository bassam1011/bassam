# Security System - Full Stack Application

نظام أمني كامل لإدارة المطلوبين وتنبيهات التعرف على الوجوه.

## 📋 المتطلبات

### Backend
- Python 3.8+
- PostgreSQL 12+
- pip

### Frontend
- أي متصفح حديث (Chrome, Firefox, Edge)

## 🚀 التثبيت والإعداد

### 1. إعداد قاعدة البيانات PostgreSQL

```bash
# افتح PostgreSQL
psql -U postgres

# أنشئ قاعدة البيانات
CREATE DATABASE security_db;

# اخرج من PostgreSQL
\q
```

### 2. إعداد Backend

```bash
# انتقل إلى مجلد Backend
cd backend

# أنشئ بيئة افتراضية (اختياري لكن موصى به)
python -m venv venv

# فعّل البيئة الافتراضية
# في Windows:
venv\Scripts\activate
# في Linux/Mac:
source venv/bin/activate

# ثبّت المتطلبات
pip install -r requirements.txt

# قم بعمل Migrations
python manage.py makemigrations
python manage.py migrate

# أنشئ حساب مدير (superuser)
python manage.py createsuperuser
# أدخل username, email, password

# شغّل السيرفر
python manage.py runserver
```

السيرفر سيعمل على: `http://localhost:8000`

### 3. إعداد Frontend

```bash
# افتح مجلد Frontend
cd frontend

# افتح login.html في المتصفح
# يمكنك استخدام Live Server في VS Code أو فتح الملف مباشرة
```

## 📁 هيكل المشروع

```
مشروع التخرج/
├── backend/
│   ├── security_system/      # إعدادات Django الرئيسية
│   │   ├── settings.py       # إعدادات المشروع
│   │   └── urls.py           # URLs الرئيسية
│   ├── users/                # تطبيق المستخدمين والمصادقة
│   │   ├── models.py         # RegistrationRequest model
│   │   ├── views.py          # Login, Register, Profile APIs
│   │   └── urls.py
│   ├── wanted/               # تطبيق المطلوبين
│   │   ├── models.py         # WantedPerson, WantedPersonPhoto
│   │   ├── views.py          # CRUD APIs للمطلوبين
│   │   └── urls.py
│   ├── alerts/               # تطبيق التنبيهات
│   │   ├── models.py         # Alert model
│   │   ├── views.py          # APIs التنبيهات مع الفلترة
│   │   └── urls.py
│   ├── manage.py
│   └── requirements.txt
└── frontend/
    ├── login.html            # صفحة تسجيل الدخول
    ├── register.html         # صفحة التسجيل
    ├── dashboard.html        # لوحة التحكم
    ├── wanted.html           # إدارة المطلوبين
    ├── alerts.html           # سجل التنبيهات
    ├── css/
    │   └── style.css         # تنسيقات شاملة
    └── js/
        ├── auth.js           # وظائف المصادقة
        ├── wanted.js         # وظائف المطلوبين
        └── alerts.js         # وظائف التنبيهات
```

## 🔌 API Endpoints

### Authentication
- `POST /api/auth/login/` - تسجيل الدخول (يرجع JWT)
- `POST /api/auth/register/` - طلب تسجيل جديد
- `GET /api/auth/profile/` - معلومات المستخدم الحالي

### Wanted Persons
- `GET /api/wanted/` - قائمة المطلوبين
- `POST /api/wanted/` - إضافة مطلوب جديد
- `GET /api/wanted/{id}/` - تفاصيل مطلوب
- `PUT /api/wanted/{id}/` - تحديث مطلوب
- `DELETE /api/wanted/{id}/` - حذف مطلوب

### Alerts
- `GET /api/alerts/` - قائمة التنبيهات (مع فلترة)
- `GET /api/alerts/?status=pending` - تنبيهات معلقة
- `GET /api/alerts/?start_date=2024-01-01&end_date=2024-12-31` - فلترة بالتاريخ
- `PUT /api/alerts/{id}/` - تحديث حالة التنبيه
- `PUT /api/alerts/{id}/confirm/` - تأكيد التنبيه
- `PUT /api/alerts/{id}/reject/` - رفض التنبيه

## 🔐 المصادقة

جميع APIs محمية بـ JWT ما عدا:
- `/api/auth/login/`
- `/api/auth/register/`

يجب إرسال Token في Header:
```
Authorization: Bearer <your_access_token>
```

## 👤 الاستخدام

### 1. إنشاء حساب
1. افتح `register.html`
2. املأ البيانات
3. انتظر موافقة المدير

### 2. تسجيل الدخول
1. افتح `login.html`
2. أدخل username/email و password
3. سيتم توجيهك للـ Dashboard

### 3. إدارة المطلوبين
1. من Dashboard اضغط "Manage Wanted Persons"
2. اضغط "+ Add Wanted Person"
3. املأ البيانات وارفع الصور
4. يمكنك التعديل أو الحذف

### 4. مراجعة التنبيهات
1. من Dashboard اضغط "View Alerts"
2. استخدم الفلاتر للبحث
3. اضغط Confirm أو Reject لكل تنبيه

## 🛠️ تطوير إضافي

### إضافة مستخدم يدوياً (للتطوير)
```bash
python manage.py createsuperuser
```

### الوصول لـ Admin Panel
```
http://localhost:8000/admin/
```
استخدم بيانات superuser للدخول

### إنشاء بيانات تجريبية
يمكنك استخدام Admin Panel لإضافة:
- Wanted Persons
- Alerts للاختبار

## 📝 ملاحظات

1. **التسجيل**: طلبات التسجيل تحتاج موافقة المدير من Admin Panel
2. **الصور**: يتم حفظ الصور في `backend/media/`
3. **CORS**: مفعّل للتطوير، عطّله في الإنتاج
4. **Secret Key**: غيّر `SECRET_KEY` في `settings.py` للإنتاج

## 🔧 استكشاف الأخطاء

### خطأ في الاتصال بقاعدة البيانات
- تأكد من تشغيل PostgreSQL
- تحقق من بيانات الاتصال في `settings.py`

### خطأ CORS
- تأكد من تشغيل Backend على port 8000
- تحقق من إعدادات CORS في `settings.py`

### الصور لا تظهر
- تأكد من إعدادات MEDIA في `settings.py`
- تحقق من صلاحيات مجلد `media/`

## 📄 الترخيص

هذا المشروع للأغراض التعليمية.
